import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from PIL import Image
import io
import graphviz
from sklearn.tree import plot_tree
from sklearn.tree import export_graphviz
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from statsmodels.stats.outliers_influence import variance_inflation_factor
import warnings
warnings.filterwarnings('ignore')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


df = pd.read_csv(r'corrected_data.csv')



label_encoder  = LabelEncoder()
column_names  = df.columns

for col in column_names:
    df[col] = label_encoder.fit_transform(df[col])



Q1 = df.quantile(0.25)
Q3 = df.quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR


df_no_outliers = df[~((df < lower_bound) | (df > upper_bound)).any(axis=1)]
original_columns  = df.columns
features = df_no_outliers.columns
scaler = StandardScaler()
df_no_outliers = scaler.fit_transform(df_no_outliers[features])
df_no_outliers = pd.DataFrame(df_no_outliers , columns=original_columns)

correlation  =df_no_outliers.corr()


X = df_no_outliers.drop(columns=['price']) 
vif_data = pd.DataFrame()
vif_data['Feature'] = X.columns
vif_data['VIF'] = [variance_inflation_factor(X.values, i) for i in range(len(X.columns))]



def compute_vif():
    dataframe  = df_no_outliers
    target_column='price'
    X = dataframe.drop(columns=[target_column])
    vif_data = pd.DataFrame()
    vif_data['Feature'] = X.columns
    vif_data['VIF'] = [variance_inflation_factor(X.values, i) for i in range(len(X.columns))]
    return vif_data



def generate_vif_figure():
    X = df_no_outliers.drop(columns=['price'])
    X = df_no_outliers.drop(columns=['Seller Type'])
    vif_data = pd.DataFrame()
    vif_data['Feature'] = X.columns
    vif_data['VIF'] = [variance_inflation_factor(X.values, i) for i in range(len(X.columns))]
    vif_data['VIF'] = vif_data['VIF'].round(2)

    fig = go.Figure(data=[go.Table(
        header=dict(
            values=["Feature", "VIF"],
            fill_color='#126ee2',
            font=dict(color='white', size=12),
            align='center'
        ),
        cells=dict(
            values=[vif_data['Feature'], vif_data['VIF']],
            fill_color=[
                ['white'] * len(vif_data),  # Background for Features
                ['#f8d7da' if 5 < v <= 10 else
                 '#f5c6cb' if 10 < v <= 20 else
                 '#f1b0b7' if v > 20 else 'white'
                 for v in vif_data['VIF']]  # Background for VIFs
            ],
            align='center',
            font=dict(size=12),
            height=30
        )
    )])

    return fig



pca = PCA()
pca.fit(df_no_outliers)

explained_variance = np.cumsum(pca.explained_variance_ratio_)
components = np.arange(1, len(explained_variance) + 1)





def pca_graph():
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=components,
        y=explained_variance,
        mode='lines+markers+text',
        text=[f"{val:.2f}" for val in explained_variance],
        textposition="top center",
        marker=dict(color='blue'),
        line=dict(dash='dash'),
        name='Explained Variance'
    ))

    fig.update_layout(
        title='PCA Scree Plot',
        xaxis_title='Number of Principal Components',
        yaxis_title='Cumulative Explained Variance',
        template='simple_white',
        showlegend=False
    )

    return fig


y = df_no_outliers['price']

x = df_no_outliers[['make', 'model', 'fuel type', 'Color', 'body type','owners', 'transmission', 'fuel economy', 'engine power', 'Location']]

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)


y_pred = model.predict(X_test)


def plot_feature_importance():
    feature_importance = model.feature_importances_
    feature_df = pd.DataFrame({
        'Feature': X_train.columns,
        'Importance': feature_importance
    }).sort_values(by='Importance', ascending=True)  # Ascending so most important is on top (after invert)

    fig = go.Figure(go.Bar(
        x=feature_df['Importance'],
        y=feature_df['Feature'],
        orientation='h',
        marker_color='skyblue'
    ))

    fig.update_layout(
        title='Feature Importance in Random Forest Regressor',
        xaxis_title='Importance',
        yaxis_title='Feature',
        template='plotly_white',
        height=500
    )

    return fig




def print_metrics(y_true, y_pred, model_name):
    model_name  = model_name
    MAE  = f"MAE : {mean_absolute_error(y_true, y_pred)}"
    MSE = f"MSE : {mean_absolute_error(y_true, y_pred)}"
    RMSE = f"RMSE:, {np.sqrt(mean_squared_error(y_true, y_pred))}"
    R2 = f"R2: {r2_score(y_true, y_pred)}"
    return model_name,MAE,MSE,RMSE,R2



linear_regression_model = LinearRegression()
linear_regression_model.fit(X_train, y_train)
y_pred_lr = linear_regression_model.predict(X_test)




coefficients = linear_regression_model.coef_
intercept = linear_regression_model.intercept_
feature_names = X_train.columns

equation = f"price = {intercept:.2f}"
for coef, feature in zip(coefficients, feature_names):
    equation += f" + ({coef:.2f} * {feature})"




linear_regression_model_data = print_metrics(y_test, y_pred_lr, "Linear Regression")
regression_equation  = equation


random_forest_model = RandomForestRegressor(n_estimators=50, random_state=42)
random_forest_model.fit(X_train, y_train)
y_pred_ = random_forest_model.predict(X_test)



random_forest_regression_data  = print_metrics(y_test, y_pred_, "Random Forest Regression")



# def random_forest_grapher():
#     from sklearn.tree import plot_tree
#     import matplotlib.pyplot as plt

#     tree = random_forest_model.estimators_[0]

#     fig, ax = plt.subplots(figsize=(20, 12))
#     plot_tree(
#         tree,
#         feature_names=X_train.columns,
#         filled=True,
#         rounded=True,
#         max_depth=3,
#         proportion=True,
#         precision=6,
#         fontsize=10,
#         ax=ax
#     )
#     ax.set_title("Random Forest Tree", fontsize=14)
#     plt.tight_layout()
#     return fig


def random_forest_grapher():
    from sklearn.tree import plot_tree
    import matplotlib.pyplot as plt
    import io
    import base64

    tree = random_forest_model.estimators_[0]

    fig, ax = plt.subplots(figsize=(20, 12))
    plot_tree(
        tree,
        feature_names=X_train.columns,
        filled=True,
        rounded=True,
        max_depth=3,
        proportion=True,
        precision=6,
        fontsize=10,
        ax=ax
    )
    ax.set_title("Random Forest Tree", fontsize=14)
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches='tight')
    plt.close(fig)
    buf.seek(0)
    encoded = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{encoded}"





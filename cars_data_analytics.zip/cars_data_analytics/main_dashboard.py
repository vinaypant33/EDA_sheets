import dash
from dash import dcc, html, Output, Input, callback , dash_table , State
from dash import Dash, html
import plotly.graph_objects as go
import graph_generator
import graph_generator_2

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


external_stylesheets = [
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
]


app = dash.Dash(__name__, external_stylesheets=external_stylesheets, suppress_callback_exceptions=True)
app.title = "Exploring Trends in - Ireland's Cars"

dashboard_title  = "Exploring Trends in - Ireland's Cars"


def create_kpi(title, value, custom_text=''):
    return go.Figure(go.Indicator(
        mode="number",
        value=value,
        number={'suffix': f" {custom_text}"},
        title={'text': title},
    ))


average_price = graph_generator.average_price
total_listings = graph_generator.total_listings
highest_price = graph_generator.highest_price
average_engine_size = graph_generator.average_engine_size


kp1 = create_kpi("Average Price", average_price , '€')
kp2 = create_kpi("Total Listings", total_listings ,'Nos')
kp3 = create_kpi("Highest Price", highest_price ,'€')
kp4 = create_kpi("Average Engine Size", average_engine_size ,'L')



car_make_count_histogram = graph_generator.car_make_count_histogram()  #  Done 
car_sales_count_histogram = graph_generator.car_sales_count_histogram()  # DOne 
fuel_type_sales_histogram = graph_generator.fuel_type_sales_histogram()  # DOne
body_color_historgam = graph_generator.body_color_histogram() # Done
body_type_count_histogram = graph_generator.body_type_count_histogram() # Done
car_location_treemap = graph_generator.car_location_treemap() # Done Eda
trannsmision_type_histogram = graph_generator.transmission_type_hiistogram()
box_plot_all = graph_generator.box_plot_all() # Done ML
voilin_plot = graph_generator.voilin_plot()  # Done ML
mileage_vs_type_scatter = graph_generator.mileage_vs_type_scatter_plot() # DOne Eda 
price_trend_line_graph = graph_generator.price_trend() # DOne
each_type_price_trend = graph_generator.each_type_price_trend() # DOne
fuel_type_pie_chart = graph_generator.fuel_type_pie_chart() # DOne Eda 
car_maek_market_share = graph_generator.car_make_market_share() # DOne Eda 





vif_table  = graph_generator_2.generate_vif_figure()
pca_graph  = graph_generator_2.pca_graph()
analysis_figure = graph_generator_2.plot_feature_importance()

random_forest_grapher  = graph_generator_2.random_forest_grapher()


# Get the meterics for the regression models: 
linear_regression_model_data = graph_generator_2.linear_regression_model_data
regression_equation  = graph_generator_2.equation

random_forest_regression_data = graph_generator_2.random_forest_regression_data


dashboard_layout = html.Div([
    html.H1(dashboard_title , style={'text-align': 'center', 'backgroundColor': '#0x0075A4'}),
    html.Div([
        html.Div(dcc.Graph(figure=kp1), className='kpi-box'),
        html.Div(dcc.Graph(figure=kp2), className='kpi-box'),
        html.Div(dcc.Graph(figure=kp3), className='kpi-box'),
        html.Div(dcc.Graph(figure=kp4), className='kpi-box'),
    ], className='kpi-container'),
    html.Div([
        html.Div(dcc.Graph(figure=car_make_count_histogram), style={'width': '49%'}),
        html.Div(dcc.Graph(figure=body_color_historgam), style={'width': '49%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Div([
        html.Div(dcc.Graph(figure=body_type_count_histogram), style={'width': '49%'}),
        html.Div(dcc.Graph(figure=fuel_type_sales_histogram), style={'width': '49%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

     html.Br(),

     html.Div([
            html.Div(dcc.Graph(figure=price_trend_line_graph), style={'width': '98%'})
        ], style={'display': 'flex', 'justify-content': 'space-between'}),

        html.Div([
            html.Div(dcc.Graph(figure=each_type_price_trend), style={'width': '98%'})
        ], style={'display': 'flex', 'justify-content': 'space-between'}),
])

eda_layout = html.Div([
    html.H1(dashboard_title , style={'text-align': 'center', 'backgroundColor': '#0x0075A4'}),
    html.Div([
        html.Div(dcc.Graph(figure=fuel_type_pie_chart), style={'width': '49%'}),
        html.Div(dcc.Graph(figure=car_maek_market_share), style={'width': '49%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    

    html.Div([
        html.Div(dcc.Graph(figure=mileage_vs_type_scatter), style={'width': '98%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Div([
        html.Div(dcc.Graph(figure=car_location_treemap), style={'width': '98%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),
])

ml_layout = html.Div([
    html.H1(dashboard_title, style={'text-align': 'center', 'backgroundColor': '#0x0075A4'}),

    html.Div([
        html.Div(dcc.Graph(figure=box_plot_all), style={'width': '98%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Div([
        html.Div(dcc.Graph(figure=voilin_plot), style={'width': '98%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Div([
        html.Div(dcc.Graph(figure=vif_table), style={'width': '49%'}),
        html.Div(dcc.Graph(figure=pca_graph), style={'width': '49%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Br(),

    html.Div([
        html.Div(dcc.Graph(figure=analysis_figure), style={'width': '100%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Br(),

    html.Hr(),

    html.Div([
        html.Div([
            html.H4(linear_regression_model_data[0]),
            html.P(linear_regression_model_data[1]),
            html.P(linear_regression_model_data[2]),
            html.P(linear_regression_model_data[3]),
            html.P(linear_regression_model_data[4]),
            html.Br(),
            html.P("Equation:"),
            html.Pre(regression_equation, style={
                'whiteSpace': 'pre-wrap',
                'wordWrap': 'break-word',
                'overflow': 'auto',
                'backgroundColor': '#f5f5f5',
                'padding': '10px',
                'borderRadius': '5px'
            })
        ], style={
            'width': '48%',
            'padding': '10px',
            'border': '1px solid #ccc',
            'boxSizing': 'border-box'
        }),

        html.Div([
            html.H4(random_forest_regression_data[0]),
            html.P(random_forest_regression_data[1]),
            html.P(random_forest_regression_data[2]),
            html.P(random_forest_regression_data[3]),
            html.P(random_forest_regression_data[4])
        ], style={
            'width': '48%',
            'padding': '10px',
            'border': '1px solid #ccc',
            'boxSizing': 'border-box'
        })
    ], style={'display': 'flex', 'justifyContent': 'space-between'}),

    html.Div([
        html.Img(src='/assets/plot.png', style={'width': '100%'})
    ], style={'display': 'flex', 'justifyContent': 'space-between'})
])




# FAB Button
fab_html = html.Div([
    dcc.Markdown('''
<input id="fabCheckbox" type="checkbox" class="fab-checkbox" />
<label class="fab" for="fabCheckbox">
  <span class="fab-dots fab-dots-1"></span>
  <span class="fab-dots fab-dots-2"></span>
  <span class="fab-dots fab-dots-3"></span>
</label>
<div class="fab-wheel">
  <a class="fab-action fab-action-1" title="Dashboard" href="/dashboard">
    <i class="fas fa-chart-pie"></i>
  </a>
  <a class="fab-action fab-action-2" title="EDA" href="/eda">
    <i class="fas fa-calculator"></i>
  </a>
  <a class="fab-action fab-action-3" title="ML Model" href="/ml">
    <i class="fas fa-robot"></i>
  </a>
</div>
    ''', dangerously_allow_html=True)
], className="fab-wrapper")


app.layout = html.Div([
  
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content'),
    fab_html
])

# Callback to switch pages
@callback(Output('page-content', 'children'), Input('url', 'pathname'))
def display_page(pathname):
    if pathname == '/eda':
        return eda_layout
    elif pathname == '/ml':
        return ml_layout
    return dashboard_layout


@app.callback(
    Output('random-forest-graph-container', 'children'),
    Input('toggle-button', 'n_clicks'),
    State('random-forest-graph-container', 'children')
)
def toggle_graph(n_clicks, current_children):
    if n_clicks % 2 == 1:
        return [dcc.Graph(figure=random_forest_grapher)]
    return []

# Custom FAB CSS
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <style>
            * { box-sizing: border-box; }
            .fab-wrapper {
              position: fixed;
              bottom: 3rem;
              right: 3rem;
              z-index: 999;
            }
            .fab-checkbox { display: none; }
            .fab {
              position: absolute;
              bottom: -1rem;
              right: -1rem;
              width: 4rem;
              height: 4rem;
              background: #126ee2;
              border-radius: 50%;
              box-shadow: 0px 5px 20px #81a4f1;
              transition: all 0.3s ease;
              z-index: 1;
              border: 1px solid #0c50a7;
              cursor: pointer;
            }
            .fab:before {
              content: "";
              position: absolute;
              width: 100%;
              height: 100%;
              left: 0;
              top: 0;
              border-radius: 50%;
              background-color: rgba(255, 255, 255, 0.1);
            }
            .fab-checkbox:checked ~ .fab:before {
              width: 90%;
              height: 90%;
              left: 5%;
              top: 5%;
              background-color: rgba(255, 255, 255, 0.2);
            }
            .fab:hover {
              background: #2c87e8;
              box-shadow: 0px 5px 20px 5px #81a4f1;
            }
            .fab-dots {
              position: absolute;
              height: 8px;
              width: 8px;
              background-color: white;
              border-radius: 50%;
              top: 50%;
              transform: translateX(0%) translateY(-50%) rotate(0deg);
              opacity: 1;
              animation: blink 3s ease infinite;
              transition: all 0.3s ease;
            }
            .fab-dots-1 { left: 15px; animation-delay: 0s; }
            .fab-dots-2 { left: 50%; transform: translateX(-50%) translateY(-50%); animation-delay: 0.4s; }
            .fab-dots-3 { right: 15px; animation-delay: 0.8s; }
            .fab-checkbox:checked ~ .fab .fab-dots { height: 6px; animation: none; }
            .fab-checkbox:checked ~ .fab .fab-dots-1 {
              width: 32px;
              border-radius: 10px;
              left: 50%;
              transform: translateX(-50%) translateY(-50%) rotate(45deg);
            }
            .fab-checkbox:checked ~ .fab .fab-dots-2 {
              transform: translateX(-50%) translateY(-50%) rotate(0deg);
            }
            .fab-checkbox:checked ~ .fab .fab-dots-3 {
              width: 32px;
              border-radius: 10px;
              right: 50%;
              transform: translateX(50%) translateY(-50%) rotate(-45deg);
            }
            @keyframes blink { 50% { opacity: 0.25; } }
            .fab-wheel {
              position: absolute;
              bottom: 0;
              right: 0;
              width: 10rem;
              height: 10rem;
              transition: all 0.3s ease;
              transform-origin: bottom right;
              transform: scale(0);
            }
            .fab-checkbox:checked ~ .fab-wheel { transform: scale(1); }
            .fab-action {
              position: absolute;
              background: black;
              width: 3rem;
              height: 3rem;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              color: white;
              box-shadow: 0 0.1rem 1rem rgba(24, 66, 154, 0.82);
              transition: all 0.3s ease;
              opacity: 0;
              cursor: pointer;
              font-size: 1.2rem;
            }
            .fab-checkbox:checked ~ .fab-wheel .fab-action { opacity: 1; }
            .fab-action:hover { background-color: #126ee2; }
            .fab-action-1 { right: -1rem; top: 0; }
            .fab-action-2 { right: 3.4rem; top: 0.5rem; }
            .fab-action-3 { left: 0.5rem; bottom: 3.4rem; }
        </style>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# Run the app
if __name__ == '__main__':
    app.run()


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings('ignore')

import plotly.express as px

df  = pd.read_csv(r'corrected_data.csv')
seat_median = df['seats'].median()
fuel_economy_median  = df['fuel economy'].median()
max_speed_median = df['max speed'].median()
engine_power_median  = df['engine power'].median()

df['seats'].fillna(seat_median , inplace=True)
df['fuel economy'].fillna(fuel_economy_median , inplace=True)
df['max speed'].fillna(max_speed_median , inplace=True)
df['engine power'].fillna(engine_power_median , inplace=True)

df = df.dropna()

df.drop_duplicates(inplace=True)


## Calculation for the KPI Indicators : 

average_price = df["price"].mean()
total_listings = len(df)
average_mileage = df["mileage"].mean()
most_common_fuel = df["fuel type"].mode()[0]
most_common_body = df["body type"].mode()[0]
average_engine_size = df["engine size"].mean()
highest_price = df["price"].max()
average_fuel_economy = df["fuel economy"].median()
most_common_seller = df["Seller Type"].mode()[0]
engine_power_by_transmission = df.groupby("transmission")["engine power"].mean().to_dict()



def car_make_count_histogram():
    fig = px.histogram(df, x='make', color='make', 
                   category_orders={'make': df['make'].value_counts().index.tolist()},
                   title="Car Make Count Plot",
                   labels={"make": "Car Make"},
                   color_discrete_sequence=px.colors.qualitative.Set2)

    fig.update_layout(
        xaxis_title="Car Make",
        yaxis_title="Count - From Total",
        xaxis_tickangle=90,
        bargap=0.1
    )
    return fig


def car_sales_count_histogram():
    fig = px.histogram(df, x='year', color='year',
                   category_orders={'year': df['year'].value_counts().index.tolist()},
                   title="Yearly Sales Count Plot",
                   labels={"year": "Yearly Sales"})

    fig.update_layout(
        xaxis_title="Yearly Sales",
        yaxis_title="Count - From Total",
        xaxis_tickangle=30,
        bargap=0.1
    )

    return fig





def fuel_type_sales_histogram(): 
    fig = px.histogram(df, x='fuel type', color='fuel type',
                   category_orders={'fuel type': df['fuel type'].value_counts().index.tolist()},
                   title="Fuel Type Count Plot",
                   labels={"fuel type": "Fuel Type"},
                   color_discrete_sequence=px.colors.qualitative.Set2)

    fig.update_layout(
        xaxis_title="Fuel Type",
        yaxis_title="Count - From Total",
        xaxis_tickangle=45,
        bargap=0.1
    )

    return fig


def body_color_histogram():
    fig = px.histogram(df, x='Color', color='Color',
                   category_orders={'Color': df['Color'].value_counts().index.tolist()},
                   title="Body Color Count Plot",
                   labels={"Color": "Body Color"},
                   color_discrete_sequence=px.colors.qualitative.Set2)

    fig.update_layout(
        xaxis_title="Body Color",
        yaxis_title="Count - From Total",
        xaxis_tickangle=45,
        bargap=0.1
    )

    return fig


def body_type_count_histogram():
    fig = px.histogram(df, x='body type', color='body type',
                   category_orders={'body type': df['body type'].value_counts().index.tolist()},
                   title="Car Body Type Count Plot",
                   labels={"body type": "Body Types"},
                   color_discrete_sequence=px.colors.sequential.Viridis)

    fig.update_layout(
        xaxis_title="Body Types",
        yaxis_title="Count - From Total",
        xaxis_tickangle=90,
        bargap=0.1
    )

    return fig



def car_location_treemap():
    make_df = df['Location'].value_counts().reset_index()
    make_df.columns = ['make', 'count']

    fig = px.treemap(make_df, 
                    path=['make'], 
                    values='count', 
                    title='Location Count- Treemap', 
                    color='count', 
                    color_continuous_scale='blues', 
                    hover_data={'make': False, 'count': True}
                    )

    fig.update_traces(textinfo='label+value', 
                    hovertemplate='Count: %{value}'
                    )

    return fig


def transmission_type_hiistogram():
    fig = px.histogram(df, x='transmission', color='Seller Type',
                   category_orders={'transmission': df['transmission'].value_counts().index.tolist()},
                   title="Transmission Type by Seller Type",
                   labels={"transmission": "Transmission Type", "Seller Type": "Seller Type"},
                   color_discrete_sequence=px.colors.sequential.Viridis)

    fig.update_layout(
        xaxis_title="Transmission Type",
        yaxis_title="Count - From Total",
        xaxis_tickangle=90,
        yaxis=dict(tickmode='linear', tick0=0, dtick=5000),
        bargap=0.1
    )

    return fig




def box_plot_all():
    fig = px.box(df, x='fuel type', y='price',
             title="Price Distribution by Fuel Type",
             labels={"fuel type": "Fuel Type", "price": "Price Distribution"},
             color='fuel type')

    fig.update_layout(
        xaxis_title="Fuel Type",
        yaxis_title="Price Distribution",
        xaxis_tickangle=90,
        template="plotly"
    )

    return fig




def voilin_plot():
    fig = px.violin(df, x='Seller Type', y='price',
                title="Price Distribution by Seller Type",
                labels={"Seller Type": "Seller Type", "price": "Price Distribution"},
                color='Seller Type', box=True, points="all")

    fig.update_layout(
        xaxis_title="Seller Type",
        yaxis_title="Price Distribution",
        xaxis_tickangle=90,
        template="plotly"
    )

    return fig


def mileage_vs_type_scatter_plot():
    fig = px.scatter(df, x='mileage', y='price', color='fuel type',
                 title="Mileage vs Price by Fuel Type",
                 labels={"mileage": "Mileage", "price": "Price"})

    fig.update_layout(
        xaxis_title="Mileage",
        yaxis_title="Price",
        xaxis_tickangle=90,
        template="plotly"
    )

    return fig

def scatter_3d():
    fig = px.scatter_3d(df, x='mileage', y='price', color='fuel type',
                 title="Mileage vs Price by Fuel Type",
                 labels={"mileage": "Mileage", "price": "Price"})

    fig.update_layout(
        xaxis_title="Mileage",
        yaxis_title="Price",
        xaxis_tickangle=90,
        template="plotly"
    )

    return fig


def price_trend():
    df_aggregated = df.groupby('year', as_index=False)['price'].mean()

    fig = px.line(df_aggregated, x='year', y='price',
                title="Price Progress Over Time",
                labels={"year": "Yearly Sales", "price": "Price"})

    fig.update_layout(
        xaxis_title="Yearly Sales",
        yaxis_title="Price",
        xaxis_tickangle=90,
        template="plotly"
    )

    return fig


def each_type_price_trend():
    df_aggregated = df.groupby(['year', 'transmission'], as_index=False)['price'].mean()

    fig = px.line(df_aggregated, x='year', y='price', color='transmission',
                title="Price Progress Over Time by Transmission Type",
                labels={"year": "Yearly Sales", "price": "Price", "transmission": "Transmission Type"})

    fig.update_layout(
        xaxis_title="Yearly Sales",
        yaxis_title="Price",
        xaxis_tickangle=90,
        template="plotly",
        legend_title="Transmission"
    )

    return fig

def fuel_type_pie_chart():
    fuel_counts = df["fuel type"].value_counts()
    fig = px.pie(values=fuel_counts.values,
                names=fuel_counts.index,
                title="Fuel Type Distribution")

    return fig

def car_make_market_share():
    location_count  = df["make"].value_counts().nlargest(10)
    fig = px.pie(values=location_count.values,
                names=location_count.index,
                title="Market Share of Each Make")

    return fig

